from dataclasses import field
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms
from django.contrib.auth import get_user_model
from .models import *

User = get_user_model()
class signupForm(UserCreationForm):
    first_name = forms.CharField(max_length=30)
    last_name = forms.CharField(max_length=30)
    email = forms.EmailField()
    class Meta:
        model=User
        fields=('first_name', 'last_name', 'email', 'password1', 'password2')

class user_detailsForm(forms.ModelForm):
    class Meta:
        model=user_details
        fields="__all__"

class CharityEventForm(forms.ModelForm):
    class Meta:
        model=CharityEvent
        fields="__all__"

class charityForm(forms.ModelForm):
    class Meta:
        model=charity
        fields="__all__"

class donorForm(forms.ModelForm):
    class Meta:
        model=donor
        fields="__all__"

class volunteerForm(forms.ModelForm):
    class Meta:
        model=volunteer
        fields="__all__"

class payment_detailsForm(forms.ModelForm):
    class Meta:
        model=payment_details
        fields="__all__"

class contact_detailsForm(forms.ModelForm):
    class Meta:
        model=contact_details
        fields="__all__"

#email subscription
class email_subscriptionForm(forms.ModelForm):
    class Meta:
        model=email_subscription
        fields="__all__"

class volunteer_work_detailsForm(forms.ModelForm):
    class Meta:
        model=volunteer_work_details
        fields="__all__"

class news_updateForm(forms.ModelForm):
    class Meta:
        model=news_update
        fields="__all__"