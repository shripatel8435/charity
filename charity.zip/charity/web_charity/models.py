from django.urls import reverse
from django.utils import timezone
from django.db import models
from django.core.validators import FileExtensionValidator
from django.utils.text import slugify
from django.contrib import messages
from django.template.defaultfilters import filesizeformat
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.contrib.auth import get_user_model
from django.utils.translation import gettext_lazy as _
from django.conf import settings
from django_resized import ResizedImageField
from PIL import Image
from io import BytesIO
from django.core.files.uploadedfile import InMemoryUploadedFile
import sys
from django.core.validators import MaxValueValidator, MinValueValidator

# Create your models here.

 

class UserManager(BaseUserManager):
    """Define a model manager for User model with no username field."""

    use_in_migrations = True

    def _create_user(self, email, password, **extra_fields):
        """Create and save a User with the given email and password."""
        if not email:
            raise ValueError('The given email must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, email, password=None, **extra_fields):
        """Create and save a regular User with the given email and password."""
        extra_fields.setdefault('is_staff', False)
        extra_fields.setdefault('is_superuser', False)
        return self._create_user(email, password, **extra_fields)

    def create_superuser(self, email, password, **extra_fields):
        """Create and save a SuperUser with the given email and password."""
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self._create_user(email, password, **extra_fields)
        



class User(AbstractUser):
    """User model."""

    username = None
    email = models.EmailField(_('email address'), unique=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    objects = UserManager()

payment_status=(('failed','failed'),
                ('success','success'))

# Volunteer user data 
class user_details(models.Model):
    first_name=models.CharField(max_length=255)
    last_name=models.CharField(max_length=255)
    email=models.EmailField()
    mobile=models.CharField(max_length=15,blank=True)
    education=models.CharField(max_length=255,blank=True)
    address=models.CharField(max_length=255,blank=True)
    about=models.TextField(blank=True)
    join_time=models.DateTimeField(blank=True,default=timezone.now)
    user_id=models.SlugField(blank=True)

    def __str__(self):
        return self.user_id
    def save(self,*args,**kwargs):
        self.user_id=slugify(str(self.email).replace('@gmail.com','')).upper()
        super(user_details,self).save()
    def get_absoulte_url(self):
        return reverse('user_details',args=[str(self.user_id)])

#event details for donation
class CharityEvent(models.Model):
    title = models.CharField(max_length=100)
    sort_description = models.TextField()
    event_thumbnail=models.ImageField(upload_to='event_image/',validators=[FileExtensionValidator(allowed_extensions=['jpeg','jpg','png'])],blank=True)
    date = models.DateField()
    start_time=models.TimeField()
    end_time=models.TimeField()
    location = models.CharField(max_length=100)
    organizer = models.CharField(max_length=100,blank=True)
    funds_raised = models.DecimalField(max_digits=10, decimal_places=2)
    target_amount = models.DecimalField(max_digits=10, decimal_places=2)
    full_description = models.TextField(blank=True)
    event_create_time = models.DateTimeField(blank=True,default=timezone.now)
    event_id=models.SlugField(blank=True,max_length=255)

    def __str__(self):
        return self.title
    def save(self,*args,**kwargs):
        self.event_id=slugify(str(self.title)+ '-' + str(self.event_create_time)).upper()
        super(CharityEvent,self).save()
    def get_absoulte_url(self):
        return reverse('CharityEvent',args=[str(self.event_id)])

#donation need to do work for charity
class charity(models.Model):
    charity_name = models.CharField(max_length=100)
    description = models.TextField()
    thumnail_image=models.ImageField(upload_to='charity_image/',validators=[FileExtensionValidator(allowed_extensions=['jpeg','jpg','png'])])
    goal_funds= models.DecimalField(max_digits=12, decimal_places=2, default=0)
    funds_raised = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    create_time=models.DateTimeField(default=timezone.now,blank=True)
    charity_id=models.SlugField(max_length=255,blank=True)

    def __str__(self):
        return self.charity_name
    def save(self,*args,**kwargs):
        self.charity_id=slugify(str(self.charity_name) + '-' + str(self.create_time))
        super(charity,self).save()
    def get_absoulte_url(self):
        return reverse('charity',args=[str(self.charity_id)])
    

#news & update details
class news_update(models.Model):
    title = models.CharField(max_length=100)
    sort_description = models.TextField()
    news_thumbnail=models.ImageField(upload_to='news_image/',validators=[FileExtensionValidator(allowed_extensions=['jpeg','jpg','png'])],blank=True)
    date = models.DateField()
    location = models.CharField(max_length=100)
    publication = models.CharField(max_length=100,blank=True)
    full_description = models.TextField(blank=True)
    news_create_time = models.DateTimeField(blank=True,default=timezone.now)
    news_id=models.SlugField(blank=True,max_length=255)

    def __str__(self):
        return self.title
    def save(self,*args,**kwargs):
        self.news_id=slugify(str(self.title)+ '-' + str(self.news_create_time)).upper()
        super(news_update,self).save()
    def get_absoulte_url(self):
        return reverse('news_update',args=[str(self.news_id)])


#charity doner details
class donor(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    mobile=models.CharField(max_length=15)
    address=models.CharField(max_length=255,blank=True)
    donated_amount = models.DecimalField(max_digits=10, decimal_places=2)
    donation_date = models.DateTimeField(default=timezone.now,blank=True)
    charity = models.CharField(max_length=255,default='all_charity')
    donor_id=models.SlugField(blank=True)

    def __str__(self):
        return f"{self.name} donated to {self.charity.name}"
    def save(self,*args,**kwargs):
        self.donor_id=slugify(self.email)
        super(donor,self).save()
    def get_absoulte_url(self):
        return reverse('donor',args=[str(self.email)])
    
#charity volunteer
class volunteer(models.Model):
    user_id=models.CharField(max_length=255)
    profile_image=models.ImageField(upload_to='volunteer_image/',validators=[FileExtensionValidator(allowed_extensions=['jpeg','jpg','png'])])
    name = models.CharField(max_length=100)
    email = models.EmailField()
    mobile=models.CharField(max_length=15)
    blood_group=models.CharField(max_length=3)
    address=models.CharField(max_length=255)
    education=models.CharField(max_length=100)
    work_profession=models.CharField(max_length=255)
    date_of_birth=models.DateField(blank=True,default=timezone.now)
    work_any_where=models.CharField(max_length=3,default='No')
    available_status=models.CharField(max_length=3,default='Yes')
    want_work_department=models.CharField(max_length=100,blank=True)
    about=models.TextField(blank=True)
    joined_date = models.DateField(auto_now_add=True)
    volunteer_id=models.SlugField(max_length=255,blank=True)

    def __str__(self):
        return f"{self.name}"
    def save(self,*args,**kwargs):
        self.volunteer_id = slugify(str(self.user_id)).upper()
        super(volunteer,self).save()
    def get_absoulte_url(self):
        return reverse('volunteer',args=[str(self.volunteer_id)])
    
#volunteer work details
class volunteer_work_details(models.Model):
    volunteer_id=models.CharField(max_length=255)
    event_name=models.CharField(max_length=255)
    event_id=models.CharField(max_length=255)
    joined_date = models.DateField(auto_now_add=True)
    disjoin_date = models.DateField(blank=True)
    
#doner payment details
class payment_details(models.Model):
    donor_email=models.CharField(max_length=255)
    donation_for=models.CharField(max_length=255,default='all_charity_work')
    transaction_id=models.CharField(max_length=255)
    amount=models.DecimalField(max_digits=10, decimal_places=2)
    status=models.CharField(choices=payment_status,max_length=50)
    payment_time=models.DateTimeField(default=timezone.now,blank=True)

    def __str__(self):
        return self.donor_email
    
#contact us details
class contact_details(models.Model):
    name=models.CharField(max_length=100)
    email=models.EmailField()
    subject=models.CharField(max_length=255)
    message=models.TextField()
    time=models.DateTimeField(default=timezone.now,blank=True)

    def __str__(self):
        return self.name
    
#newslatter subscraption
class email_subscription(models.Model):
    email=models.EmailField()
    time=models.DateTimeField(default=timezone.now,blank=True)


#forgot password data
class forgot_password_data(models.Model):
    email=models.EmailField()
    token=models.TextField()
    uid=models.TextField()
    time=models.DateField()
    token_id=models.TextField()

    def __str__(self):
        return self.token_id