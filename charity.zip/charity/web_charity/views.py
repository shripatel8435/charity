from django.http import HttpResponseRedirect
from django.shortcuts import render,redirect,get_object_or_404
from .models import *
from .forms import *
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import permission_required
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.contrib.auth.models import Group,Permission
from django.contrib.auth.forms import PasswordChangeForm,PasswordResetForm
from django.contrib.auth import update_session_auth_hash

from django.utils.encoding import force_bytes, force_str
from django.utils.http import urlsafe_base64_encode
from django.core.mail import send_mail
import uuid
from datetime import datetime,date

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from django.db.models import Count 
from django.utils import timezone
from datetime import timedelta
from collections import Counter
from datetime import datetime, timedelta, time
from django.views.decorators.csrf import csrf_exempt
import razorpay
from .main import razorpay_client
from django.utils.timezone import now
import pytz

#home page function
def index(request):
    try:
        total_donation=payment_details.objects.all().count()
        total_donor=donor.objects.all().count()
        total_event=CharityEvent.objects.all().count()
        total_volunteer=volunteer.objects.all().count()
        news=news_update.objects.all().order_by('-news_create_time')[:2]
        charitys=CharityEvent.objects.all().order_by('-event_create_time')[:2]
        charity_for=charity.objects.all().order_by('-create_time')[:3]
        data_list={'total_donation':total_donation,
                'total_donor':total_donor,
                'total_event':total_event,
                'total_volunteer':total_volunteer,
                'news':news,
                'charity':charitys,
                'charity_for':charity_for}
        return render(request,'index.html',data_list)
    except:
        return render(request,'error_page.html')

#404 error page
def error_404(request):
    return render(request,'404.html')


#about page function
def about(request):
    return render(request,'about.html')

#social event list
def social_events(request):
    try:
        current_date = timezone.now()
        event_list=CharityEvent.objects.filter(date__gte=current_date).order_by('date')
        data_list={'event_list':event_list}
        return render(request,'events.html',data_list)
    except:
        return render(request,'error_page.html')

#news and updates
def news_updates(request):
    try:
        news=news_update.objects.all().order_by('-news_create_time')
        data_list={'news':news}
        return render(request,'news_update.html',data_list)
    except:
        return render(request,'error_page.html')


#terms & condition page
def terms(request):
    return render(request,'terms_condition.html')

#privacy policy page
def privacy_policy(request):
    return render(request,'privacy_policy.html')

#contact us page
def contactus(request):
    try:
        if request.method=='POST':
            form=contact_detailsForm(request.POST)
            if form.is_valid():
                form.save()
                messages.success(request,'your message record successfuly')
                return HttpResponseRedirect(request.META['HTTP_REFERER'])
            else:
                messages.error(request,'your message not record ,please try again')
                return HttpResponseRedirect(request.META['HTTP_REFERER'])
        else:
            return render(request,'contact.html')
    except:
        return render(request,'error_page.html')

#donation page
def donate(request):
    try:
        if request.method == 'POST':
            form=donorForm(request.POST)
            email=request.POST.get('email')
            user_id=request.session.get('email')
            if (request.user.is_authenticated):
                if (user_id == email):
                    if form.is_valid():
                        email=request.POST.get('email')
                        form.save()
                        donor_id=slugify(email)
                        return redirect('donation_payment',donor_id=donor_id)
                    else:
                        messages.error(request,'your donation request is failed ,please try again')
                        return HttpResponseRedirect(request.META['HTTP_REFERER'])
                else:
                    messages.error(request,'please use your login email id to make donation')
                    return HttpResponseRedirect(request.META['HTTP_REFERER'])
            else:
                if form.is_valid():
                    email=request.POST.get('email')
                    form.save()
                    donor_id=slugify(email)
                    return redirect('donation_payment',donor_id=donor_id)
                else:
                    messages.error(request,'your donation request is failed ,please try again')
                    return HttpResponseRedirect(request.META['HTTP_REFERER'])
        else:
            return render(request,'donation.html')
    except:
        return render(request,'error_page.html')


#make payment for the donation
def donation_payment(request,donor_id):
    try:
        timezone='UTC'
        tz = pytz.timezone(timezone)
        current_time = now().astimezone(tz)
        
        find_donor=donor.objects.filter(donor_id=donor_id).order_by('-donation_date')[:1]
        donated_amount=0
        saved_datetime=''
        for i in find_donor:
            saved_datetime=i.donation_date
            donated_amount=i.donated_amount
        time_difference = abs(current_time - saved_datetime)
        if (find_donor.count() >=1) and (time_difference <= timedelta(minutes=5)):
            currency = 'INR'
            callback_url = f'http://127.0.0.1:8000/verify_payment/{donor_id}'
            amount=float(donated_amount) * 100
            razorpay_order = razorpay_client.order.create(dict(amount=amount,
                        currency=currency,
                        payment_capture='0'))
            razorpay_order_id = razorpay_order['id']
            data_list={'currency':currency,
                    'donor':find_donor,
                    'donated_amount':donated_amount,
                        'callback_url' : callback_url,
                        'razorpay_amount' : amount,
                        'razorpay_order_id':razorpay_order_id,
                        'razorpay_merchant_key' : settings.RAZOR_KEY_ID,}
            return render(request,'donation_payment.html',data_list)
        else:
            messages.error(request,'your donation request no more longer please make it again')
            return redirect('/donate')
    except:
        return render(request,'error_page.html')
    
#verify donation payment
@csrf_exempt
def verify_payment(request,donor_id):
    try:
        if request.method == 'POST':
            find_donor=donor.objects.filter(donor_id=donor_id).order_by('-donation_date')[:1]
            donated_amount=0
            donor_email=''
            for i in find_donor:
                donated_amount=i.donated_amount
                donor_email=i.email
            payment_id = request.POST.get('razorpay_payment_id', '')
            razorpay_order_id = request.POST.get('razorpay_order_id', '')
            signature = request.POST.get('razorpay_signature', '')
            coustomer_id=request.session.get('email')
            params_dict = {
                'razorpay_order_id': razorpay_order_id,
                'razorpay_payment_id': payment_id,
                'razorpay_signature': signature,
            }
            
            amount=float(donated_amount) * 100
            # verify the payment signature.
            result = razorpay_client.utility.verify_payment_signature(
                params_dict)
            if result:
                try:
                    razorpay_client.payment.capture(payment_id, amount)
                    payment_transaction=payment_details(donor_email=donor_email,
                                                        amount=(donated_amount),transaction_id=params_dict['razorpay_payment_id'],
                                                        status='success')
                    payment_transaction.save()
                    messages.success(request,'Thank you so much for the donation.')
                    return redirect('/donate')
                except:
                    razorpay_client.payment.capture(payment_id, amount)
                    payment_transaction=payment_details(donor_email=donor_email,
                                                        amount=(donated_amount),transaction_id=params_dict['razorpay_payment_id'],
                                                        status='failed')
                    payment_transaction.save()
                    messages.success(request,'your donation payment is failed, please try again')
                    return redirect('/donate')
            else:
                messages.error(request,'Donation payment is Fail due to payment verification')
                return redirect('/donate')
        else:
            return redirect('/404')
    except:
        messages.error(request,'Donation payment failed due to some technical error, please try again later.')
        return redirect('/donate')



#login page for the user
def login_page(request):
    try:
        if request.user.is_authenticated:
            return redirect('/')
        else:
            if request.method=='POST':
                email=request.POST.get('email')
                password=request.POST.get('password')
                user=authenticate(request,username=email,password=password)
                if user is not None:
                    login(request,user)
                    user1=get_object_or_404(User,email=email)
                    request.session['email']=user1.email
                    return redirect('/')
                else:
                    messages.error(request,'unvalid user email and password id, please try again')
                    return HttpResponseRedirect(request.META['HTTP_REFERER'])
            else:
                return render(request,'login.html')
    except:
        messages.error(request,'something went wrong!')
        return render(request,'error_page.html')

#signup page
def signup_page(request):
    try:
        if request.user.is_authenticated:
            return redirect('/')
        else:
            if request.method=="POST":
                email=request.POST.get('email')
                password=request.POST.get('password1')
                password1=request.POST.get('password2')
                find_user=User.objects.filter(email=email).count()
                find_user2=user_details.objects.filter(email=email).count()
                if find_user==0 and find_user2==0:
                    if password==password1:
                        form=signupForm(request.POST)
                        form2=user_detailsForm(request.POST)
                        if form.is_valid() and form2.is_valid():
                            form.save()
                            form2.save()
                            user=authenticate(request,username=email,password=password)
                            login(request,user)
                            request.session['email']=email
                            messages.success(request,'Your account create successfuly')
                            return redirect('/')
                        else:
                            messages.error(request,'Unvalid data entry please try again')
                            return HttpResponseRedirect(request.META['HTTP_REFERER'])
                    else:
                        messages.error(request,'Password and confirm password not match')
                        return HttpResponseRedirect(request.META['HTTP_REFERER'])
                else:
                    messages.error(request,'This email account already registered')
                    return HttpResponseRedirect(request.META['HTTP_REFERER'])
            else:
                return render(request,'signup.html')
    except:
        messages.error(request,'something went wrong!')
        return render(request,'error_page.html')


#email subscription
def subscription_by_email(request):
    try:
        if request.method == 'POST':
            form = email_subscriptionForm(request.POST)
            if form.is_valid():
                form.save()
                messages.success(request,'thank you for subscription')
                return HttpResponseRedirect(request.META['HTTP_REFERER'])
            else:
                messages.error(request,'somethings went wrong')
                return HttpResponseRedirect(request.META['HTTP_REFERER'])
    except:
        messages.error(request,'somethings went wrong please try again')
        return render(request,'error_page.html')
    
#forgot password of user account
def forgot_password(request):
    try:
        if not request.user.is_authenticated:
            if request.method=='POST':
                email=request.POST.get('email',)
                user3=int(User.objects.filter(email=email).count())
                time=date.today()
                if user3==1:
                    user1=get_object_or_404(User,email=email)
                    uid=urlsafe_base64_encode(force_bytes(user1.pk))
                    token=str(uuid.uuid4())
                    token_id=str(email+uid+token+str(time)).upper()
                    forgot_data=forgot_password_data(email=email,token=token,uid=uid,time=time,token_id=token_id)
                    forgot_data.save()
                    subject='login password reset link by Charity'
                    message=f'User {user1.first_name} account password reset link http://127.0.0.1:8000/recover_password/{uid}/{token}/{email}/{time} '
                    email_form=settings.EMAIL_HOST_USER
                    email_to=[email]
                    send_mail(subject,message,email_form,email_to)
                    messages.success(request,'password reset link send on your email !')
                    return HttpResponseRedirect(request.META['HTTP_REFERER'])
                else:
                    messages.error(request,'user not found !')
                    return HttpResponseRedirect(request.META['HTTP_REFERER'])
            else:
                return render(request,'forgot_password.html')
        else:
            return redirect('/')
    except:
        return render(request,'error_page.html')
    
# forgot password recover
def recover_password(request,token,uid,email,time):
    try:
        if not request.user.is_authenticated:
            time1=str(date.today())
            time2=str(time)
            token_id=str(email+uid+token+str(time)).upper()
            number=forgot_password_data.objects.filter(token_id=token_id).count()
            if time1==time2 and number==1:
                user1=User.objects.get(email=email)
                return render(request,'recover_password.html',{'token_id':token_id,'user':user1})
            else:
                return redirect('/404')       
        else:
            return redirect('/')
    except:
        messages.error(request,'something went wrong!')
        return render(request,'error_page.html')
    
#user password recovery done
def recover_password_done(request,token_id):
    try:
        if request.method=='POST':
            find_token=forgot_password_data.objects.filter(token_id=token_id).count()
            if find_token==1:
                find_data=forgot_password_data.objects.get(token_id=token_id)
                email=find_data.email
                all_user=int(User.objects.filter(email=email).count())
                if all_user==1:
                    user1=User.objects.get(email=email)
                    email=request.POST.get('email',)
                    first_name=request.POST.get('first_name',)
                    last_name=request.POST.get('last_name',)
                    Password=request.POST.get('password1',)
                    Password2=request.POST.get('password2',)
                    if email==user1.email and first_name==user1.first_name and last_name==user1.last_name:
                        if Password==Password2:
                            form=signupForm(request.POST,instance=user1)
                            if form.is_valid():
                                form.save()
                                find_data.delete()
                                user=authenticate(request,username=user1.email,password=Password)
                                login(request,user)
                                request.session['email']=user1.email
                                messages.success(request,'your login password reset ,welcome back !')
                                return redirect('/')
                            else:
                                messages.error(request,'user is not register')
                                return HttpResponseRedirect(request.META['HTTP_REFERER'])
                        else:
                            messages.error(request,'Your password not match to each other')
                            return HttpResponseRedirect(request.META['HTTP_REFERER'])
                    else:
                        messages.error(request,'Unvalid data entry')
                        return HttpResponseRedirect(request.META['HTTP_REFERER'])
                else:
                    messages.error(request,'user is not register')
                    return HttpResponseRedirect(request.META['HTTP_REFERER'])
            else:
                messages.error(request,'unvaild request please resend forgot link and try again')
                return HttpResponseRedirect(request.META['HTTP_REFERER'])
        else:
            return redirect('/')
    except:
        messages.error(request,'something went wrong!')
        return render(request,'error_page.html')


#logout user form platform
@login_required(login_url='/login')
def logout_user(request):
    try:
        logout(request)
    except KeyError:
        messages.error(request,'somethings went wrong please try again')
    return redirect('/')


#news details
def news_details(request,news_id):
    try:
        news=get_object_or_404(news_update,news_id=news_id)
        data_list={'news':news}
        return render(request,'news_details.html',data_list)
    except:
        return render(request,'error_page.html')


#events details
def event_details(request,event_id):
    event=get_object_or_404(CharityEvent,event_id=event_id)
    data_list={'event':event}
    return render(request,'events_details.html',data_list)


#user profile pages
@login_required(login_url='/login')
def profile(request):
    try:
        if request.user.is_superuser:
            return redirect('/admin_dashboard')
        else:
            user_id=request.session.get('email')
            user=get_object_or_404(user_details,email=user_id)
            if request.method =='POST':
                email=request.POST.get('email')
                form=user_detailsForm(request.POST, instance=user)
                if form.is_valid() and (user.email == email):
                    form.save()
                    messages.success(request,'your details update successfuly')
                    return HttpResponseRedirect(request.META['HTTP_REFERER'])
                else:
                    messages.error(request,'your details not update please try again')
                    return HttpResponseRedirect(request.META['HTTP_REFERER'])
            else:
                password_form=PasswordChangeForm(request.user, request.POST)
                data_list={'user':user,
                        'password_form':password_form}
                return render(request,'user_page/dashboard.html',data_list)
    except:
        return render(request,'error_page.html')

#user donation list
@login_required(login_url='/login')
def donation_list(request):
    try:
        user_id=request.session.get('email')
        payment=payment_details.objects.filter(donor_email=user_id).order_by('-payment_time')
        data_list={'payment':payment}
        return render(request,'user_page/donation_list.html',data_list)
    except:
        return render(request,'error_page.html')

#change password
@login_required(login_url='/login')
def change_password(request):
    try:
        if request.method == 'POST':
            form = PasswordChangeForm(request.user, request.POST)
            if form.is_valid():
                user = form.save()
                update_session_auth_hash(request, user)
                messages.success(request, 'Your password was successfully updated!')
                return redirect('/profile')
            else:
                messages.error(request, 'Please Enter Correct Password.')
                return HttpResponseRedirect(request.META['HTTP_REFERER'])
        else:
            return redirect('/404')
    except:
        messages.error(request,'something went wrong!')
        return render(request,'error_page.html')
    
#become volunteer 
@login_required(login_url='/login')
def volunteer_form(request):
    try:
        user_id=request.session.get('email')
        find_volunteer=volunteer.objects.filter(user_id=user_id).count()
        user=''
        if find_volunteer == 1:
            user=get_object_or_404(volunteer,user_id=user_id)
        else:
            user=get_object_or_404(user_details,email=user_id)
        if request.method=='POST':
            form_user_id=request.POST.get('user_id')
            form=''
            if find_volunteer == 0:
                form=volunteerForm(request.POST,request.FILES)
            else:
                form=volunteerForm(request.POST,request.FILES,instance=user)
            if form.is_valid() and (user_id == form_user_id):
                form.save()
                if (find_volunteer == 0):
                    messages.success(request,'thank you for the join us as a volunteer')
                else:
                    messages.success(request,'volunteer details update successfuly')
                return redirect('/profile')
            else:
                messages.error(request,'unvalid data entery please try again')
                return HttpResponseRedirect(request.META['HTTP_REFERER'])
        else:
            data_list={'user':user}
            if find_volunteer == 0:
                return render(request,'user_page/become_volunteer.html',data_list)
            else:
                return render(request,'user_page/edit_volunteer_details.html',data_list)
    except:
        return render(request,'error_page.html')
    

#admin use funactions start here
#admin use funactions start here
#admin use funactions start here
#admin use funactions start here


#admin dashboard
@login_required(login_url='/login')
def admin_dashboard(request):
    try:
        if request.user.is_superuser:
            total_user=user_details.objects.all().count()
            last_100_user=user_details.objects.all().order_by('-join_time')[:100]
            total_volunteer=volunteer.objects.all().count()
            last_100_volunteer=volunteer.objects.all().order_by('-joined_date')[:100]
            total_donation=payment_details.objects.filter(status='success').count()
            last_100_donation=payment_details.objects.filter(status='success').order_by('-payment_time')[:100]
            data_list={'total_user':total_user,
                    'last_100_user':last_100_user,
                    'total_volunteer':total_volunteer,
                    'last_100_volunteer':last_100_volunteer,
                    'total_donation':total_donation,
                    'last_100_donation':last_100_donation}
            return render(request,'admin_page/dashboard.html',data_list)
        else:
            return redirect('/404')
    except:
        return render(request,'error_page.html')
    
#admin volunteer list
@login_required(login_url='/login')
def volunteer_list(request):
    try:
        if request.user.is_superuser:
            volunteer_list=volunteer.objects.all().order_by('-joined_date')
            data_list={'volunteer_list':volunteer_list}
            return render(request,'admin_page/volunteer_list.html',data_list)
        else:
            return redirect('/404')
    except:
        return render(request,'error_page.html')
    
#admin volunteer list
@login_required(login_url='/login')
def volunteer_details(request,volunteer_id):
    try:
        if request.user.is_superuser:
            user=get_object_or_404(volunteer,volunteer_id=volunteer_id)
            data_list={'user':user}
            return render(request,'admin_page/volunteer_details.html',data_list)
        else:
            return redirect('/404')
    except:
        return render(request,'error_page.html')

#USER LIST
@login_required(login_url='/login')
def user_list(request):
    try:
        if request.user.is_superuser:
            user_list=user_details.objects.all()
            data_list={'user_list':user_list}
            return render(request,'admin_page/user_list.html',data_list)
        else:
            return redirect('/404')
    except:
        return render(request,'error_page.html')

#user details  
@login_required(login_url='/login')
def user_detail(request, user_id):
    if request.user.is_superuser:
        try:
            user = get_object_or_404(user_details, user_id=user_id)
            data_list = {'user': user}
            return render(request, 'admin_page/user_details.html', data_list)
        except user_details.DoesNotExist:
            return render(request, 'error_page.html')
    else:
        return redirect('/404')
    
#donation list
@login_required(login_url='/login')
def admin_donation_list(request):
    try:
        if request.user.is_superuser:
            donation_list=payment_details.objects.filter(status='success')
            data_list={'donation_list':donation_list}
            return render(request,'admin_page/donation_list.html',data_list)
        else:
            return redirect('/404')
    except:
        return render(request,'error_page.html')
    

#donation details
@login_required(login_url='/login')
def donation_details(request,transaction_id):
    try:
        if request.user.is_superuser:
            donation=get_object_or_404(payment_details,transaction_id=transaction_id)
            donor_email=donation.donor_email
            user=''
            if user_details.objects.filter(email=donor_email).exists():
                user=get_object_or_404(user_details,email=donor_email)
            data_list={'donation':donation,
                       'user':user}
            return render(request,'admin_page/donation_details.html',data_list)
        else:
            return redirect('/404')
    except:
        return render(request,'error_page.html')

#event list
@login_required(login_url='/login')
def admin_event_list(request):
    try:
        if request.user.is_superuser:
            event_list=CharityEvent.objects.all().order_by('-event_create_time')
            data_list={'event_list':event_list}
            return render(request,'admin_page/event_list.html',data_list)
        else:
            return redirect('/404')
    except:
        return render(request,'error_page.html')
    
#admin event details
@login_required(login_url='/login')
def admin_event_details(request,event_id):
    try:
        if request.user.is_superuser:
            event=get_object_or_404(CharityEvent,event_id=event_id)
            if request.method == 'POST':
                form=CharityEventForm(request.POST,request.FILES,instance=event)
                if form.is_valid():
                    form.save()
                    messages.success(request,'event details update successfuly')
                    return redirect('/admin_event_list')
                else:
                    messages.error(request,'event details not update')
                    return HttpResponseRedirect(request.META['HTTP_REFERER'])
            else:
                data_list={'event':event}
                return render(request,'admin_page/event_details.html',data_list)
        else:
            return redirect('/404')
    except:
        return render(request,'error_page.html')
    
#create event details
@login_required(login_url='/login')
def admin_event_create(request):
    try:
        if request.user.is_superuser:
            if request.method == 'POST':
                form=CharityEventForm(request.POST,request.FILES)
                if form.is_valid():
                    form.save()
                    messages.success(request,'event create successfuly')
                    return redirect('/admin_event_list')
                else:
                    messages.error(request,'unvalid data entry please try again')
                    return HttpResponseRedirect(request.META['HTTP_REFERER'])
            else:
                return render(request,'admin_page/create_event.html')
        else:
            return redirect('/404')
    except:
        return render(request,'error_page.html')

#delete event details
@login_required(login_url='/login')
def admin_event_delete(request,event_id):
    try:
        if request.user.is_superuser:
            event=get_object_or_404(CharityEvent,event_id=event_id)
            event.delete()
            messages.success(request,'event delete succssfuly')
            return redirect('/admin_event_list')
        else:
            return redirect('/404')
    except:
        return render(request,'error_page.html')
    
#news & update list
@login_required(login_url='/login')
def news_update_list(request):
    try:
        if request.user.is_superuser:
            news_list=news_update.objects.all().order_by('-news_create_time')
            data_list={'news_list':news_list}
            return render(request,'admin_page/news_list.html',data_list)
        else:
            return redirect('/404')
    except:
        return render(request,'error_page.html')

#create news 
@login_required(login_url='/login')
def admin_news_create(request):
    try:
        if request.user.is_superuser:
            if request.method == 'POST':
                form=news_updateForm(request.POST,request.FILES)
                if form.is_valid():
                    form.save()
                    messages.success(request,'news details create successfuly')
                    return redirect('/news_update_list')
                else:
                    messages.error(request,'news not create please try again')
                    return HttpResponseRedirect(request.META['HTTP_REFERER'])
            else:
                return render(request,'admin_page/create_news.html')
        else:
            return redirect('/404')
    except:
        return render(request,'error_page.html')
    
#news details
@login_required(login_url='/login')
def admin_news_details(request,news_id):
    try:
        if request.user.is_superuser:
            news=get_object_or_404(news_update,news_id=news_id)
            if request.method == 'POST':
                form=news_updateForm(request.POST,request.FILES,instance=news)
                if form.is_valid():
                    form.save()
                    messages.success(request,'news details update successfuly')
                    return redirect('/news_update_list')
                else:
                    messages.error(request,'news details not update successfuly')
                    return HttpResponseRedirect(request.META['HTTP_REFERER'])
            else:
                data_list={'news':news}
                return render(request,'admin_page/news_details.html',data_list)
        else:
            return redirect('/404')
    except:
        return render(request,'error_page.html')
    

#delete news
@login_required(login_url='/login')
def admin_delete_news(request,news_id):
    try:
        if request.user.is_superuser:
            news=get_object_or_404(news_update,news_id=news_id)
            news.delete()
            messages.success(request,'news details delete successfuly')
            return redirect('/news_update_list')
        else:
            return redirect('/404')
    except:
        return render(request,'error_page.html')

    
#charity list
@login_required(login_url='/login')
def admin_charity_list(request):
    try:
        if request.user.is_superuser:
            charity_list=charity.objects.all().order_by('-create_time')
            data_list={'charity_list':charity_list}
            return render(request,'admin_page/charity_list.html',data_list)
        else:
            return redirect('/404')
    except:
        return render(request,'error_page.html')
    
#create charity
@login_required(login_url='/login')
def admin_charity_create(request):
    try:
        if request.user.is_superuser:
            if request.method=='POST':
                form=charityForm(request.POST,request.FILES)
                if form.is_valid():
                    form.save()
                    messages.success(request,'charity create successfuly')
                    return redirect('/admin_charity_list')
                else:
                    messages.error(request,'charity not create please try again')
                    return HttpResponseRedirect(request.META['HTTP_REFERER'])
            else:
                return render(request,'admin_page/create_charity.html')
        else:
            return redirect('/404')
    except:
        return render(request,'error_page.html')
    

#charity details
@login_required(login_url='/login')
def admin_charity_details(request,charity_id):
    try:
        if request.user.is_superuser:
            charity_data=get_object_or_404(charity,charity_id=charity_id)
            if request.method=='POST':
                form=charityForm(request.POST,request.FILES,instance=charity_data)
                if form.is_valid():
                    form.save()
                    messages.success(request,'charity update successfuly')
                    return redirect('/admin_charity_list')
                else:
                    messages.error(request,'charity not update please try again')
                    return HttpResponseRedirect(request.META['HTTP_REFERER'])
            else:
                data_list={'charity':charity_data}
                return render(request,'admin_page/charity_details.html',data_list)
        else:
            return redirect('/404')
    except:
        return render(request,'error_page.html')
            

#delete charity 
@login_required(login_url='/login')
def delete_charity(request,charity_id):
    try:
        if request.user.is_superuser:
            charity_data=get_object_or_404(charity,charity_id=charity_id)
            messages.success(request,'charity delete successfuly')
            return redirect('/admin_charity_list')
        else:
            return redirect('/404')
    except:
        return render(request,'error_page.html')
        
