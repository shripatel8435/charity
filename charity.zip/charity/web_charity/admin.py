from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin
from django.utils.translation import gettext_lazy as _
from .models import *


from django.contrib.auth import get_user_model
User = get_user_model()
@admin.register(User)
class user_detailsAdmin(DjangoUserAdmin):
    """Define admin model for custom User model with no email field."""
    model=User
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        (_('Personal info'), {'fields': ('first_name', 'last_name')}),
        (_('Permissions'), {'fields': ('is_active', 'is_staff', 'is_superuser',
                                       'groups', 'user_permissions')}),
        (_('Important dates'), {'fields': ('last_login', 'date_joined')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'password1', 'password2'),
        }),
    )
    list_display = ('email', 'first_name', 'last_name', 'is_staff')
    search_fields = ('email', 'first_name', 'last_name')
    ordering = ('email',)

#user admin details
@admin.register(user_details)
class user_detailsAdmin(admin.ModelAdmin):
    list_display=('first_name','email','mobile','join_time')
    search_fields=('first_name','email','mobile','join_time')

#charity event details
@admin.register(CharityEvent)
class CharityEventAdmin(admin.ModelAdmin):
    list_display=('title','date','sort_description')
    search_fields=('title','date','sort_description')

#charity work
@admin.register(charity)
class charityAdmin(admin.ModelAdmin):
    list_display=('charity_name','create_time')
    search_fields=('charity_name','create_time')

#donor details
@admin.register(donor)
class donorAdmin(admin.ModelAdmin):
    list_display=('name','email','donation_date')
    search_fields=('name','email','donation_date')

#volunteer details
@admin.register(volunteer)
class volunteerAdmin(admin.ModelAdmin):
    list_display=('user_id','email','want_work_department','joined_date')
    search_fields=('user_id','email','want_work_department','joined_date')

#payment details
@admin.register(payment_details)
class payment_detailsAdmin(admin.ModelAdmin):
    list_display=('donor_email','donation_for','payment_time')
    search_fields=('donor_email','donation_for','payment_time')

#contact us details
@admin.register(contact_details)
class contact_detailsAdmin(admin.ModelAdmin):
    list_display=('name','subject','time')
    search_fields=('name','subject','time')

#email subscription
@admin.register(email_subscription)
class email_subscriptionAdmin(admin.ModelAdmin):
    list_display=('email','time')
    search_fields=('email','time')

#volunteer work details
@admin.register(volunteer_work_details)
class volunteer_work_detailsAdmin(admin.ModelAdmin):
    list_display=('volunteer_id','event_name','joined_date')
    search_fields=('volunteer_id','event_name','joined_date')

#news and update details
@admin.register(news_update)
class news_updateAdmin(admin.ModelAdmin):
    list_display=('title','date','publication')
    search_fields=('title','date','publication')