
  // Disable right-click
  document.addEventListener('contextmenu', function(event) {
    event.preventDefault();
  });

  // Disable common keyboard shortcuts used for inspection
  document.addEventListener('keydown', function(event) {
    // Check for Ctrl+Shift+I (Chrome, Firefox, Edge)
    if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key === 'I') {
      event.preventDefault();
    }
    // Check for Ctrl+Shift+J (Chrome, Firefox, Edge)
    if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key === 'J') {
      event.preventDefault();
    }
    // Check for Ctrl+Shift+C (Chrome, Firefox, Edge)
    if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key === 'C') {
      event.preventDefault();
    }
    // Check for Ctrl+U (Chrome, Firefox)
    if ((event.ctrlKey || event.metaKey) && event.key === 'U') {
      event.preventDefault();
    }
  });
