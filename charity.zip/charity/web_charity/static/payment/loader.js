window.addEventListener("load", function() {
  // Hide the loader
  document.querySelector('.loader-wrapper').style.display = 'none';
  // Show the content
  document.querySelector('.second_portion').style.display = 'block';
});
window.addEventListener("beforeunload", function() {
  // Show the loader before the page is redirected
  document.querySelector('.loader-wrapper').style.display = 'block';
});
