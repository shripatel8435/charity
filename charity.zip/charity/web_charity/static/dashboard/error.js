function close_tap(){
		document.getElementById("error_popup").style.display='none';
	}
function close_tap1(){
		document.getElementById("error_popup").style.display='none';
	}