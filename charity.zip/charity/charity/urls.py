"""charity URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from web_charity import views
from django.urls import path,include
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns = [
    path('admin/', admin.site.urls),
    path("accounts/",include("allauth.urls")),
    path('',views.index,name='index'),
    path('about',views.about,name='about'),
    path('404',views.error_404,name='error_404'),
    path('social-events',views.social_events,name='social_events'),
    path('news-update',views.news_updates,name='news_updates'),
    path('contactus',views.contactus,name='contactus'),
    path('donate',views.donate,name='donate'),
    path('login',views.login_page,name='login_page'),
    path('signup',views.signup_page,name='signup_page'),
    path('subscription_by_email',views.subscription_by_email,name='subscription_by_email'),
    path('forgot-password',views.forgot_password,name='forgot_password'),
    path('recover_password/<uid>/<token>/<email>/<time>',views.recover_password,name='recover_password'),
    path('recover_password_done/<token_id>',views.recover_password_done,name='recover_password_done'),
    path('logout',views.logout_user,name='logout_user'),
    path('terms',views.terms,name='terms'),
    path('privacy_policy',views.privacy_policy,name='privacy_policy'),
    path('news-details/<slug:news_id>',views.news_details,name='news_details'),
    path('event-details/<slug:event_id>',views.event_details,name='event_details'),
    path('donation_payment/<slug:donor_id>',views.donation_payment,name='donation_payment'),
    path('verify_payment/<slug:donor_id>',views.verify_payment,name='verify_payment'),


    #user use url list
    path('profile',views.profile,name='profile'),
    path('change_password',views.change_password,name='change_password'),
    path('donate-list',views.donation_list,name='donation_list'),
    path('volunteer-form',views.volunteer_form,name='volunteer_form'),


    #admin use urls list
    path('admin_dashboard',views.admin_dashboard,name='admin_dashboard'),
    path('volunteer_list',views.volunteer_list,name='volunteer_list'),
    path('volunteer_details/<slug:volunteer_id>',views.volunteer_details,name='volunteer_details'),
    path('user_list',views.user_list,name='user_list'),
    path('user_detail/<slug:user_id>',views.user_detail,name='user_detail'),
    path('admin_donation_list',views.admin_donation_list,name='admin_donation_list'),
    path('donation_details/<slug:transaction_id>',views.donation_details,name='donation_details'),
    path('admin_event_list',views.admin_event_list,name='admin_event_list'),
    path('admin_event_details/<slug:event_id>',views.admin_event_details,name='admin_event_details'),
    path('admin_event_create',views.admin_event_create,name='admin_event_create'),
    path('admin_event_delete/<slug:event_id>',views.admin_event_delete,name='admin_event_delete'),
    path('news_update_list',views.news_update_list,name='news_update_list'),
    path('admin_news_create',views.admin_news_create,name='admin_news_create'),
    path('admin_news_details/<slug:news_id>',views.admin_news_details,name='admin_news_details'),
    path('admin_delete_news/<slug:news_id>',views.admin_delete_news,name='admin_delete_news'),
    path('admin_charity_list',views.admin_charity_list,name='admin_charity_list'),
    path('admin_charity_create',views.admin_charity_create,name='admin_charity_create'),
    path('admin_charity_details/<slug:charity_id>',views.admin_charity_details,name='admin_charity_details'),
    path('delete_charity/<slug:charity_id>',views.delete_charity,name='delete_charity'),

]+ static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
